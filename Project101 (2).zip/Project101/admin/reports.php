<?php
session_start();
include("../connection.php");
include("../function.php");

$user_data = check_slogin($con);

$program_id = $_SESSION['prog_id'];

$sql = "select * from c_map where prog_id = '$program_id'";
$query = mysqli_query($con, $sql);

$c_map = mysqli_fetch_all($query, MYSQLI_ASSOC);


$sql2 = "select prog_name from program where prog_id = '$program_id'";
$query2 = mysqli_query($con, $sql2);

$program = mysqli_fetch_assoc($query2);

// select count(*) from c_map where title = "title" 


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <title>Reports</title>
    <style>
        body {
            background-color: #e9e2c7;
        }

        .hover {
            background-color: #9c1d24;
            color: white;
        }

        a {
            text-decoration: none;
            color: white
        }

        a:hover {
            background-color: white !important;
            color: black
        }

        .graph {
            height: 370px;
            width: 100%;
        }
    </style>
    
</head>
<nav>
	<input id="nav-toggle" type="checkbox">
	<ul class="links">
		<a href="enroll.php">Back</a>
	</ul>
	<label for="nav-toggle" class="icon-burger">
		<div class="line"></div>
		<div class="line"></div>
		<div class="line"></div>
	</label>
</nav>
<body>
    <div class="container mt-5">
        <br>
        <div class="card">
            <div class="card-header">
                <h4>Reports</h4>
            </div>
            <div class="card-body">
                <br>
                <div class="card text-center">
                    <a href="" data-bs-toggle="modal" data-bs-target="#taxModal">
                        <div class="hover card-header m-3">
                        <br>
                            <h4>TAXONOMY ANALYTICS</h4>
                        <br>
                        </div>
                    </a>
                </div>
                <br>
                <div class="card text-center">
                    <a href="analytics.php">
                    <div class="hover card-header m-3">
                    <br>
                        <h4>ANALYTICS VISUALIZATION</h4>
                        <!-- <div class="graph" id="chartContainer"></div> -->
                    <br>
                    </div>
                    </a>
                </div>
                <br>
                <div class="card text-center">
                    <a href="" data-bs-toggle="modal" data-bs-target="#remarksModal">
                        <div class="hover card-header m-3">
                        <br>
                            <h4>ANALYTICS REMARKS</h4>
                        <br>
                        </div>
                    </a>
                </div>
                <br>
            </div>
            
        </div>
        <!-- Tax modal -->
            <div class="modal fade" id="taxModal" tabindex="-1" aria-labelledby="taxModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Taxonomy Analytics</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h1 class='text-center'><?php echo $program['prog_name']?></h1>
                        <table class="table table-bordered border-dark">
                            <thead class="text-center">
                                <tr>
                                    <th>Subject</th>
                                    <th colspan="2">Circulation</th>
                                    <th colspan="2">Filipiniana</th>
                                    <th>E-Books</th>
                                    <th>General Reference</th>
                                    <th>Manuscript</th>
                                    <th>Taxonomy Level</th>
                                </tr>
                                <tr>
                                    <th></th>
                                    <th>Title</th>
                                    <th>Volume</th>
                                    <th>Title</th>
                                    <th>Volume</th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody class="table-group-divider text-center">
                            <!-- Tax Table List -->
                            <?php
                            $titles = [];
                            $titlesFil = [];
                            $totalCopies = [];
                            $totalCopiesFil = [];
                            $isExist = [];
                            $isMaterials = [];
                            $size = 0;
                            $numberMaterials = 0;

                            foreach ($c_map as $list) {
                                $sub = $list['curricul_sub'];
                                $materials = $list['materials'];

                                if(in_array($sub, $isExist)) {
                                    continue;
                                }
                                
                                else {
                                    $isExist[$size] = $sub;
                                    $sql = "SELECT *,COUNT(*),SUM(no_copies) as total FROM `c_map` WHERE curricul_sub = '$sub' AND class = 'Circulation' AND prog_id = '$program_id';";
                                    $run_title = mysqli_query($con, $sql);

                                    $titleRow = mysqli_fetch_assoc($run_title);
                                    $titleCount = $titleRow['COUNT(*)']; // Get the count from the result
                                    $title = $list['title'];
                                    if (!isset($titles[$title])) {
                                        $titles[$title] = 0; // Initialize the title count if it's not set
                                        $totalCopies[$title] = 0; // Initialize the total copies for the title
                                    }
                                    $titles[$title]++;
                                    $totalCopies[$title] += $titleRow['total'];

                                    $sql2 = "SELECT *,COUNT(*),SUM(no_copies) as total FROM `c_map` WHERE curricul_sub = '$sub' AND class = 'Filipiniana' AND prog_id = '$program_id';";
                                    $run_title2 = mysqli_query($con, $sql2);

                                    $titleRow2 = mysqli_fetch_assoc($run_title2);

                                    $titleCount2 = $titleRow2['COUNT(*)']; // Get the count from the result

                                    $title2 = $list['title'];
                                    if (!isset($titlesFil[$title2])) {
                                        $titlesFil[$title2] = 0; // Initialize the title count if it's not set
                                        $totalCopiesFil[$title2] = 0; // Initialize the total copies for the title
                                    }
                                    $titlesFil[$title2]++;
                                    $totalCopiesFil[$title2] += $titleRow2['total'];
                                    $size++;
                                    
                                    $sql3 = "SELECT COUNT(*) FROM `c_map` WHERE `curricul_sub` = '$sub' AND `class` = 'E-Book'";
                                    $run_title3 = mysqli_query($con, $sql3);
                                    $titleRow3 = mysqli_fetch_assoc($run_title3);

                                    $sql4 = "SELECT COUNT(*) FROM `c_map` WHERE `curricul_sub` = '$sub' AND `class` = 'General Reference'";
                                    $run_title4 = mysqli_query($con, $sql4);
                                    $titleRow4 = mysqli_fetch_assoc($run_title4);
                                    
                                    $sql5 = "SELECT COUNT(DISTINCT materials) as totalCount FROM c_map WHERE curricul_sub = '$sub'";
                                    $run_types = mysqli_query($con, $sql5);
                                    $nMaterials = mysqli_fetch_assoc($run_types);
                                    
                                    $numberMaterials = $nMaterials['totalCount'];
                                    
                                    $sql6 = "SELECT COUNT(*) FROM c_map WHERE curricul_sub = '$sub' AND class = 'Manuscript'";
                                    $run_title6 = mysqli_query($con, $sql6);
                                    $titleRow6 = mysqli_fetch_assoc($run_title6);
                                }



                                
                                ?>

                                <tr>
                                    <td><?php echo htmlspecialchars($list['curricul_sub']) ?></td>
                                    <td><?php echo $titleCount ?></td>
                                    <td><?php echo $totalCopies[$title] ?></td>
                                    <td><?php echo $titleCount2 ?></td>
                                    <td><?php if($titleCount2 == 0) {echo 0;} else {echo $totalCopiesFil[$title2];} ?></td>
                                    <td><?php echo $titleRow3['COUNT(*)']?></td>
                                    <td><?php echo $titleRow4['COUNT(*)']?></td>
                                    <td><?php echo $titleRow6['COUNT(*)']?></td>
                                    <td><?php 
                                        if($numberMaterials == 6) {
                                            echo "5";
                                        }
                                        else if($numberMaterials == 5) {
                                            echo "4";
                                        }
                                        else if($numberMaterials == 4) {
                                            echo "3";
                                        }
                                        else if($numberMaterials == 3) {
                                            echo "2";
                                        }
                                        else if($numberMaterials == 2) {
                                            echo "1";
                                        }
                                        else {
                                            echo "0";
                                        }
                                    ?></td>
                                </tr>
                            <?php
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
                </div>
            </div>
        <!--  -->

        <!-- Remarks modal -->
        <div class="modal fade" id="remarksModal" tabindex="-1" aria-labelledby="remarksModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Taxonomy Remarks</h1><br>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h1 class='text-center'><?php echo $program['prog_name']?></h1>
                    <table class="table table-bordered border-dark">
                        <thead class="text-center">
                            <tr>
                                <th>Subject</th>
                                <th colspan="2">Circulation</th>
                                <th colspan="2">Filipiniana</th>
                                <th>E-Books</th>
                                <th>General Reference</th>
                                <th>Manuscript</th>
                                <th>Remarks</th>
                            </tr>
                            <tr>
                                <th></th>
                                <th>Title</th>
                                <th>Volume</th>
                                <th>Title</th>
                                <th>Volume</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody class="table-group-divider text-center">
                        <!-- Tax Table List -->
                        <?php
                            $titles = [];
                            $titlesFil = [];
                            $totalCopies = [];
                            $totalCopiesFil = [];
                            $isExist = [];
                            $isMaterials = [];
                            $size = 0;
                            $numberMaterials = 0;

                            foreach ($c_map as $list) {
                                $sub = $list['curricul_sub'];
                                $materials = $list['materials'];

                                if(in_array($sub, $isExist)) {
                                    continue;
                                } else {
                                    $isExist[$size] = $sub;
                                    $isMaterials[$size] = $materials;

                                    $types = explode(",", $materials);

                                    $numberOfTypes = count($types);

                                    $sql = "SELECT *,COUNT(*),SUM(no_copies) as total FROM `c_map` WHERE curricul_sub = '$sub' AND class = 'Circulation' AND prog_id = '$program_id';;";
                                    $run_title = mysqli_query($con, $sql);

                                    $titleRow = mysqli_fetch_assoc($run_title);
                                    $titleCount = $titleRow['COUNT(*)']; // Get the count from the result
                                    $title = $list['title'];
                                    if (!isset($titles[$title])) {
                                        $titles[$title] = 0; // Initialize the title count if it's not set
                                        $totalCopies[$title] = 0; // Initialize the total copies for the title
                                    }
                                    $titles[$title]++;
                                    $totalCopies[$title] += $titleRow['total'];

                                    $sql2 = "SELECT *,COUNT(*),SUM(no_copies) as total FROM `c_map` WHERE curricul_sub = '$sub' AND class = 'Filipiniana' AND prog_id = '$program_id';";
                                    $run_title2 = mysqli_query($con, $sql2);

                                    $titleRow2 = mysqli_fetch_assoc($run_title2);

                                    $titleCount2 = $titleRow2['COUNT(*)']; // Get the count from the result

                                    $title2 = $list['title'];
                                    if (!isset($titlesFil[$title2])) {
                                        $titlesFil[$title2] = 0; // Initialize the title count if it's not set
                                        $totalCopiesFil[$title2] = 0; // Initialize the total copies for the title
                                    }
                                    $titlesFil[$title2]++;
                                    $totalCopiesFil[$title2] += $titleRow2['total'];
                                    $size++;
                                }

                                $sql3 = "SELECT COUNT(*) FROM `c_map` WHERE `curricul_sub` = '$sub' AND `class` = 'E-Book'";
                                $run_title3 = mysqli_query($con, $sql3);
                                $titleRow3 = mysqli_fetch_assoc($run_title3);

                                $sql4 = "SELECT COUNT(*) FROM `c_map` WHERE `curricul_sub` = '$sub' AND `class` = 'General Reference'";
                                $run_title4 = mysqli_query($con, $sql4);
                                $titleRow4 = mysqli_fetch_assoc($run_title4);

                                $sql5 = "SELECT COUNT(DISTINCT materials) as totalCount FROM c_map WHERE curricul_sub = '$sub'";
                                $run_types = mysqli_query($con, $sql5);
                                $nMaterials = mysqli_fetch_assoc($run_types);
                                
                                $numberMaterials = $nMaterials['totalCount'];
                                
                                $sql6 = "SELECT COUNT(*) FROM c_map WHERE curricul_sub = '$sub' AND class = 'Manuscript'";
                                $run_title6 = mysqli_query($con, $sql6);
                                $titleRow6 = mysqli_fetch_assoc($run_title6);
                                
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($list['curricul_sub']) ?></td>
                                    <td><?php echo $titleCount ?></td>
                                    <td><?php echo $totalCopies[$title] ?></td>
                                    <td><?php echo $titleCount2 ?></td>
                                    <td><?php if($titleCount2 == 0) {echo 0;} else {echo $totalCopiesFil[$title2];} ?></td>
                                    <td><?php echo $titleRow3['COUNT(*)']?></td>
                                    <td><?php echo $titleRow4['COUNT(*)']?></td>
                                    <td><?php echo $titleRow6['COUNT(*)']?></td>
                                    <td><?php
                                        if($numberMaterials == 6) {
                                            echo "Comprehensive Level";
                                        }
                                        else if($numberMaterials == 5) {
                                            echo "Research Level";
                                        }
                                        else if($numberMaterials == 4) {
                                            echo "Study Level";
                                        }
                                        else if($numberMaterials == 3) {
                                            echo "Basic Information Level";
                                        }
                                        else if($numberMaterials == 2) {
                                            echo "Minimal Information Level";
                                        }
                                        else {
                                            echo "No Level";
                                        }

                                    
                                    ?></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                </div>
            </div>
            </div>
        </div>
        <!--  -->
        
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>