<?php
	session_start();

	include("../connection.php");
	include("../function.php");

	$user_data = check_slogin($con);

	$sql = "select * from program";
	$result = mysqli_query($con,$sql);

	$programs_list = mysqli_fetch_all($result, MYSQLI_ASSOC);

	if(isset($_POST['enter']) ) {
		$program = $_POST['program'];
		$curr_sub = $_POST['curr_subject'];
		$title = $_POST['title'];
		$author = $_POST['author'];
		$year = $_POST['year'];
		$publisher = $_POST['publisher'];
		$no_copies = $_POST['no_copies'];
		$class = $_POST['class'];
		$type = $_POST['flexCheckboxDefault'];
		$materials = implode(",",$type);


		$run_sql = "INSERT INTO `c_map` (`cmap_id`, `prog_id`, `curricul_sub`, `title`, `author`, `year`, `publisher`, `no_copies`, `class`, `materials`) VALUES (NULL, '$program', '$curr_sub', '$title', '$author', '$year', '$publisher', '$no_copies', '$class', '$materials')";
		$query = mysqli_query($con,$run_sql);

    }

	if(isset($_POST['update'])) {

		if($_POST['edit_program'] != null) {
			$run = "SELECT cmap_id FROM c_map ORDER BY cmap_id DESC LIMIT 1";
			$result = mysqli_query($con, $run);
			if ($result) {
				$row = mysqli_fetch_assoc($result);
				$lastId = $row['cmap_id'];

				$program = $_POST['edit_program'];
				$curr_sub = $_POST['edit_curr_sub'];
				$title = $_POST['edit_title'];
				$author = $_POST['edit_author'];
				$year = $_POST['edit_year'];
				$publisher = $_POST['edit_publisher'];
				$no_copies = $_POST['edit_no_copies'];
				$class = $_POST['edit_class'];
				$materials = $_POST['edit_materials'];

				$upd_sql = "UPDATE `c_map` SET `prog_id`='$program',`curricul_sub`='$curr_sub',`title`='$title',`author`='$author',`year`='$year',`publisher`='$publisher',`no_copies`='$no_copies',`class`='$class',`materials`='$materials' WHERE cmap_id=$lastId";
				$query = mysqli_query($con, $upd_sql);


				if($query) {
					echo "<script>alert('Successfully Updated.')</script>";
				}

			}
		} else {
			echo "<script>alert('No values to be edited.')</script>";
		}

		
	}

	if(isset($_POST['generate'])) {
		$_SESSION['prog_id'] = $_POST['program'];
		header("Location: reports.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
	<title>C-Map Analytics</title>
</head>
<nav>
	<input id="nav-toggle" type="checkbox">
	<ul class="links">
		<li><a href="../index.php">Dashboard</a></li>
		<li><a href="enroll.php" class="active">CMap</a></li>
		<a href="" data-bs-toggle="modal" data-bs-target="#LogoutModal">Logout</a>
	</ul>
	<label for="nav-toggle" class="icon-burger">
		<div class="line"></div>
		<div class="line"></div>
		<div class="line"></div>
	</label>
</nav>
<body style="background-color: #e9e2c7;">
	<div class="modal fade" id="LogoutModal" tabindex="-1" aria-labelledby="LogoutModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">
	      	<div class="text-center">
	      		<h6>Do you wanna Logout?</h6>
	      		<a href="../logout.php" class="edit_btn">Yes</a>
	      	</div>
	      </div>
	      <div class="modal-footer">
	      </div>
	    </div>
	  </div>
	</div>
	<div class="container">
		<h2>C-Map Analytics</h2>
		<div class="container-inside">
			<form method="post">
				
			<!-- Display -->
				<div class="row">
					<div class="col">
						<!--  -->
						<div class="row">
							<div class="col">
								<select class="form-select" id="program" name="program">
									<option disabled>Please Choose...</option>
									<?php foreach ($programs_list as $lists) { ?>
										<option value="<?php echo htmlspecialchars($lists['prog_id'])?>"><?php echo htmlspecialchars($lists['prog_name'])?></option>
									<?php } ?>
								</select>
							</div>
							
							<div class="col">

							</div>
						</div>
						<!--  -->
						<br>
						<div class="mb-3 row">
							<label class="col-sm-4 col-form-label">Curriculum Subject</label>
							<div class="col-sm-6">
							<input type="text" class="form-control" name="curr_subject" onkeypress="return ValidateAlpha(event)">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-4 col-form-label">Title</label>
							<div class="col-sm-6">
							<input type="text" class="form-control" name="title">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-4 col-form-label">Author</label>
							<div class="col-sm-6">
							<input type="text" class="form-control" name="author" onkeypress="return ValidateAlpha(event)">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-4 col-form-label">Year</label>
							<div class="col-sm-6">
							<input type="text" class="form-control" name="year" onkeypress="return onlyNumberKey(event)" maxlength="4">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-4 col-form-label">Publisher</label>
							<div class="col-sm-6">
							<input type="text" class="form-control" name="publisher" onkeypress="return ValidateAlpha(event)">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-4 col-form-label">Number of Copies</label>
							<div class="col-sm-6">
							<input type="text" class="form-control" name="no_copies" onkeypress="return onlyNumberKey(event)">
							</div>
						</div>
						<div class="mb-3 row">
							<label class="col-sm-4 col-form-label">Class</label>
							<div class="col-sm-6">
								<select class="form-select" id="class" name="class">
									<option disabled>Please Choose...</option>
									<option>Circulation</option>
									<option>Filipiniana</option>
									<option>E-Book</option>
									<option>General Reference</option>
									<option>Manuscript</option>
								</select>
							</div>
						</div>

						<!-- radios type of materials -->
						
						<label class="col-sm-4 col-form-label">Type of Materials</label>
						<div class="row">
							<div class="col-sm-1">

							</div>
							<div class="col">
								<div class="form-check">
									<input class="form-check-input" type="checkbox" name="flexCheckboxDefault[]" id="flexCheckboxDefault1" value="Book/Monograph">
									<label class="form-check-label"for="flexCheckboxDefault1">
										Book / Monograph
									</label>
								</div>
								<div class="form-check">
									<input class="form-check-input" type="checkbox" name="flexCheckboxDefault[]" id="flexCheckboxDefault2" value="Periodical">
									<label class="form-check-label"for="flexCheckboxDefault2">
										Periodical
									</label>
								</div>
								<div class="form-check">
									<input class="form-check-input" type="checkbox" name="flexCheckboxDefault[]" id="flexCheckboxDefault3" value="Electronic Resources Online">
									<label class="form-check-label"for="flexCheckboxDefault3">
										Electronic Resources Online
									</label>
								</div>
							</div>
							<div class="col">
								<div class="form-check">
									<input class="form-check-input" type="checkbox" name="flexCheckboxDefault[]" id="flexCheckboxDefault4" value="Foreign Language">
									<label class="form-check-label"for="flexCheckboxDefault4">
										Foreign Language
									</label>
								</div>
								<div class="form-check">
									<input class="form-check-input" type="checkbox" name="flexCheckboxDefault[]" id="flexCheckboxDefault5" value="Manuscript">
									<label class="form-check-label"for="flexCheckboxDefault5">
										Manuscript
									</label>
								</div>
								<div class="form-check">
									<input class="form-check-input" type="checkbox" name="flexCheckboxDefault[]" id="flexCheckboxDefault6" value="Well Known Authors">
									<label class="form-check-label"for="flexCheckboxDefault6">
										Well Known Authors
									</label>
								</div>
							</div>

						</div>
						<!--  -->

						<!-- buttons -->
						<div class="row">
							<div class="col-sm">
								<button type="submit" name="enter" class="btn btn-danger">Enter</button>
							</div>
							<div class="col-sm">
								<button type="submit" name="generate" class="btn btn-danger">Generate Reports</button>
							</div>
						</div>
					</div>
					<!--  -->
					<br>
					<!-- 2nd column -->
					<div class="col-sm-4">
						<div class="row border border-danger p-3">
						
							<?php if(isset($_POST['enter'])) { ?>
								
								<div class="col">

									<p>Book:</p>
									<p>Curriculum Subject:</p>
									<p>Title:</p>
									<p>Author:</p>
									<p>Year:</p>
									<p>Publisher:</p>
									<p>No. of Copies:</p>
									<p>Class:</p>
									<p>Type of Materials:</p>
									
								</div>
								<div class="col">
									<p> <input type="text" class="form-control" name="edit_program" value="<?php echo $program?>" onkeypress="return ValidateAlpha(event)"></p>
									<p><input type="text" class="form-control" name="edit_curr_sub" value="<?php echo $curr_sub?>" onkeypress="return ValidateAlpha(event)"></p>
									<p><input type="text" class="form-control" name="edit_title" value="<?php echo $title?>" onkeypress="return ValidateAlpha(event)"></p>
									<p><input type="text" class="form-control" name="edit_author" value="<?php echo $author?>" onkeypress="return ValidateAlpha(event)"></p>
									<p><input type="text" class="form-control" name="edit_year" value="<?php echo $year?>" onkeypress="return onlyNumberKey(event)"  maxlength="4"></p>
									<p><input type="text" class="form-control" name="edit_publisher" value="<?php echo $publisher?>" onkeypress="return ValidateAlpha(event)"></p>
									<p><input type="text" class="form-control" name="edit_no_copies" value="<?php echo $no_copies?>" onkeypress="return onlyNumberKey(event)"></p>
									<p><input type="text" class="form-control" name="edit_class" value="<?php echo $class?>" onkeypress="return ValidateAlpha(event)"></p>
									<p><input type="text" class="form-control" name="edit_materials" value="<?php echo $materials?>" onkeypress="return ValidateAlpha(event)"></p>
								</div>
							<?php }?>
							<div>
								<button type="submit" name="update" class="btn btn-danger">Update</button>
							</div>
						</div>
					</div>
				</div>

			</form>
		</div>
	</div>
	<script>
        function onlyNumberKey(evt) {
	        var ASCIICode = (evt.which) ? evt.which : evt.keyCode
	        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
	            return false;
	        return true;
        }
        function ValidateAlpha(evt) {
			var keyCode = (evt.which) ? evt.which : evt.keyCode;
			if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode !== 32 && keyCode !== 44 && keyCode !== 46) {
				return false;
			}
			return true;
		}

    </script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</body>
</html>