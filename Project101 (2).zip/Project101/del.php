<?php
    include("connection.php");

    $id = $_GET['del'];

    $sql_del = "DELETE FROM program where prog_id = '$id'";
    $run = mysqli_query($con, $sql_del);

    header("Location: index.php");